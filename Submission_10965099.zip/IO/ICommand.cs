﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MortalEngines.IO
{
    public interface ICommand
    {

    }
}
