﻿using MortalEngines.Entities.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace MortalEngines.Models.Machines
{
    public class Fighter : BaseMachine, IFighter
    {
        private bool agressiveMode;
        private const double InitialHealth = 200;

        public Fighter(string name, double attackPoints, double defensePoints)
            : base(name, attackPoints + 50, defensePoints - 25, InitialHealth)
        {
            this.AggressiveMode = true;
        }

        public bool AggressiveMode { get; private set; }


        public void ToggleAggressiveMode()
        {
            if (AggressiveMode == true)
            {
                AggressiveMode = false;
                this.AttackPoints -= 50;
                this.DefensePoints += 25;
            }
            else
            {
                AggressiveMode = true;
                this.AttackPoints += 50;
                this.DefensePoints -= 25;
            }
        }

        public override string ToString()
        {
            string agressiveModeInfo = this.AggressiveMode == true ? "ON" : "OFF";

            return base.ToString() + Environment.NewLine + $" *Aggressive: {agressiveModeInfo}";
        }

    }
}
