﻿using MortalEngines.Entities.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace MortalEngines.Models.Machines.Factories
{
    public class TankFactory
    {
        public ITank CreateMachine(string name, double attackPoints, double defensePoints)
        {
            var tank = new Tank(name, attackPoints, defensePoints);

            return tank;
        }
    }
}
