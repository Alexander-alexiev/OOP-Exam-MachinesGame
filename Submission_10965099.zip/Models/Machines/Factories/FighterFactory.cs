﻿using MortalEngines.Entities.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace MortalEngines.Models.Machines.Factories
{
    public class FighterFactory
    {
        public IFighter CreateMachine(string name, double attackPoints, double defensePoints)
        {
            var fighter = new Fighter(name, attackPoints, defensePoints);

            return fighter;
        }
    }
}
