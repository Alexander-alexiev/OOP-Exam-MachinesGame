﻿using MortalEngines.Entities.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace MortalEngines.Models.Pilots.Factory
{
    public class PilotFactory
    {
        public IPilot CreateMachine(string name)
        {
            var pilot = new Pilot(name);

            return pilot;
        }
    }
}
