﻿namespace MortalEngines.Core
{
    using Contracts;
    using MortalEngines.Entities.Contracts;
    using MortalEngines.Models.Machines;
    using MortalEngines.Models.Machines.Factories;
    using MortalEngines.Models.Pilots;
    using MortalEngines.Models.Pilots.Factory;
    using System.Collections.Generic;
    using System.Linq;

    public class MachinesManager : IMachinesManager
    {
        private IList<IPilot> pilots;
        private IList<IFighter> fighters;
        private IList<ITank> tanks;
        private TankFactory tankfactory;
        private PilotFactory pilotFactory;
        private FighterFactory fighterFactory;
        private IList<IMachine> machines;

        public MachinesManager()
        {
            this.pilots = new List<IPilot>();
            this.fighters = new List<IFighter>();
            this.tanks = new List<ITank>();
            this.machines = new List<IMachine>();
            this.tankfactory = new TankFactory();
            this.pilotFactory = new PilotFactory();
            this.fighterFactory = new FighterFactory();
        }

        public string HirePilot(string name)
        {
            IPilot pilot = pilots.FirstOrDefault(p => p.Name == name);

            if (pilot == null)
            {
               var pilotToAdd = pilotFactory.CreateMachine(name);
                pilots.Add(pilotToAdd);
                return $"Pilot {name} hired";
            }
            else
            {
                return $"Pilot {name} is hired already";
            }
        }

        public string ManufactureTank(string name, double attackPoints, double defensePoints)
        {
            ITank tank = tanks.FirstOrDefault(p => p.Name == name);

            if (tank == null)
            { 
                var tankToAdd = tankfactory.CreateMachine(name, attackPoints, defensePoints);
                tanks.Add(tankToAdd);
                machines.Add(tankToAdd);
                return $"Tank {name} manufactured - attack: {tankToAdd.AttackPoints:f2}; defense: {tankToAdd.DefensePoints:f2}";
            }
            else
            {
                return $"Machine {name} is manufactured already";
            }

        }

        public string ManufactureFighter(string name, double attackPoints, double defensePoints)
        {
            IFighter fighter = fighters.FirstOrDefault(p => p.Name == name);

            if (fighter == null)
            {
                var fighterToAdd = fighterFactory.CreateMachine(name, attackPoints, defensePoints);
                fighters.Add(fighterToAdd);
                machines.Add(fighterToAdd);
                return $"Fighter {name} manufactured - attack: {fighterToAdd.AttackPoints:f2}; defense: {fighterToAdd.DefensePoints:f2}; aggressive: ON";
            }
            else
            {
                return $"Machine {name} is manufactured already";
            }
        }

        public string EngageMachine(string selectedPilotName, string selectedMachineName)
        {
            ITank tank = tanks.FirstOrDefault(p => p.Name == selectedMachineName);
            IFighter fighter = fighters.FirstOrDefault(p => p.Name == selectedMachineName);
            IPilot pilot = pilots.FirstOrDefault(p => p.Name == selectedPilotName);

            if (pilot == null)
            {
                return $"Pilot {selectedPilotName} could not be found";
            }
            else if (tank == null && fighter == null)
            {
                return $"Machine {selectedMachineName} could not be found";
            }
            //else if (tank.Pilot && fighter.Pilot != null)
            //{
            //    return $"Machine {selectedMachineName} is already occupied";
            //}
            else
            {
                if (tank != null)
                {
                    tank.Pilot = pilot;
                    pilot.AddMachine(tank);
                    return $"Pilot {selectedPilotName} engaged machine {selectedMachineName}";
                }
                else
                {
                    fighter.Pilot = pilot;
                    pilot.AddMachine(fighter);
                    return $"Pilot {selectedPilotName} engaged machine {selectedMachineName}";
                }
                
            }

        }

        public string AttackMachines(string attackingMachineName, string defendingMachineName)
        {
            IMachine attackingMachine = machines.FirstOrDefault(p => p.Name == attackingMachineName);
            IMachine defendinggMachine = machines.FirstOrDefault(p => p.Name == defendingMachineName);

            if (attackingMachine == null)
            {
                return $"Machine {attackingMachineName} could not be found";
            }
            else if (defendinggMachine == null)
            {
                return $"Machine {defendingMachineName} could not be found";
            }
            else if (attackingMachine.HealthPoints <= 0)
            {
                return $"Dead machine {attackingMachineName} cannot attack or be attacked";
            }
            else if (defendinggMachine.HealthPoints <= 0)
            {
                return $"Dead machine {defendingMachineName} cannot attack or be attacked";

            }
            else
            {
                attackingMachine.Attack(defendinggMachine);
                return $"Machine {defendingMachineName} was attacked by machine {attackingMachineName} - current health: {defendinggMachine.HealthPoints}";
            }
        }

        public string PilotReport(string pilotReporting)
        {
            IPilot pilot = pilots.FirstOrDefault(p => p.Name == pilotReporting);

            return pilot.Report();
        }

        public string MachineReport(string machineName)
        {
            ITank tank = tanks.FirstOrDefault(p => p.Name == machineName);
            IFighter fighter = fighters.FirstOrDefault(p => p.Name == machineName);
            if (tank != null)
            {
                return tank.ToString();
            }
            else
            {
               return fighter.ToString();
            }

            
        }

        public string ToggleFighterAggressiveMode(string fighterName)
        {
            IFighter fighter = fighters.FirstOrDefault(p => p.Name == fighterName);

            if (fighter == null)
            {
                return $"Machine {fighterName} could not be found";
            }
            else
            {
                fighter.ToggleAggressiveMode();
                return $"Fighter {fighterName} toggled aggressive mode";
            }
        }

        public string ToggleTankDefenseMode(string tankName)
        {
            ITank tank = tanks.FirstOrDefault(p => p.Name == tankName);

            if (tankName == null)
            {
                return $"Machine {tankName} could not be found";
            }
            else
            {
                tank.ToggleDefenseMode();
                return $"Fighter {tankName} toggled aggressive mode";
            }
        }
    }
}