﻿using MortalEngines.IO;
using MortalEngines.IO.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MortalEngines.Core.Contracts
{
    public class Engine : IEngine
    {
        private MachinesManager machinesManager;

        public Engine()
        {
            machinesManager = new MachinesManager();
        }
        
        public void Run()
        {
            string input = Console.ReadLine();

            while (input != "Quit")
            {
                try
                {
                    string[] inputArgs = input.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                    string command = inputArgs[0];

                    string[] args = inputArgs.Skip(1).ToArray();

                    string result = ReadCommands(command, args);

                    Console.WriteLine(result);
                }
                catch (Exception iox)
                {
                    Console.WriteLine("Error: " + iox.Message);
                }
                
                input = Console.ReadLine();
            }
            
        }
        private string ReadCommands(string command, string[] args)
        {
            string result = string.Empty;
            string name = string.Empty;
            double attackPoints = 0;
            double defensePoints = 0;
            switch (command)
            {
                case "HirePilot":
                    name = args[0];
                    result = this.machinesManager.HirePilot(name);
                    break;
                case "PilotReport":
                    name = args[0];
                    result = this.machinesManager.PilotReport(name);
                    break;
                case "ManufactureTank":
                    name = args[0];
                    attackPoints = double.Parse(args[1]);
                    defensePoints = double.Parse(args[2]);
                    result = this.machinesManager.ManufactureTank(name, attackPoints, defensePoints);
                    break;
                case "ManufactureFighter":
                    name = args[0];
                    attackPoints = double.Parse(args[1]);
                    defensePoints = double.Parse(args[2]);
                    result = this.machinesManager.ManufactureFighter(name, attackPoints, defensePoints);
                    break;
                case "MachineReport":
                    name = args[0];
                    result = this.machinesManager.MachineReport(name);
                    break;
                case "AggressiveMode":
                    name = args[0];
                    result = this.machinesManager.ToggleFighterAggressiveMode(name);
                    break;
                case "DefenseMode":
                    name = args[0];
                    result = this.machinesManager.ToggleTankDefenseMode(name);
                    break;
                case "Engage":
                    string pilotName = args[0];
                    string machineName = args[1];
                    result = this.machinesManager.EngageMachine(pilotName, machineName);
                    break;
                case "Attack":
                    string attackingMachineName = args[0];
                    string defendinggMachineName = args[1];
                    result = this.machinesManager.AttackMachines(attackingMachineName, defendinggMachineName);
                    break;
            }
            return result;
        }
    }
}
